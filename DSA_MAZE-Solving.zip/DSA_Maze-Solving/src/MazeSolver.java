import java.util.Stack;

public class MazeSolver {
    Maze maze;
    Rat rat;
    Stack stack;

    int [][] mazeMesh =
            {
            {1,1,1,1,1,1,1,1,1,1,1,1},
            {0,0,0,1,0,0,1,0,0,0,0,1},
            {1,0,1,1,0,1,1,0,1,1,0,1},
            {1,0,0,0,0,0,1,0,0,1,0,1},
            {1,1,1,1,0,1,1,1,1,1,0,1},
            {1,0,0,0,0,0,0,0,0,0,0,0},
            {1,1,1,1,1,1,1,1,1,1,1,1}
            };
    public static void main(String[] args) {
        new MazeSolver();
    }

    public MazeSolver(){
        int direction = 0;
        maze = new Maze(mazeMesh);
        rat = new Rat(maze);
        stack = new Stack();
        maze.markMoved(rat.getLocation());
        while (!rat.isOut()){
            if(rat.canMove(direction)){
                rat.move(direction);
                stack.push(rat.getLocation());
            }else{
                if(direction<3)
                    direction++;
                else
                    direction = 0;
            }
            maze.print();
        }
    }

}

/*



 */
